//crc.cpp
#include <iostream.h>
int main()
{
    int i,j,k,l;
     
    //Get Frame
    int fs;
    cout<<"\n Enter Size of data: ";
    cin>>fs;
     
    int f[20];
     
    cout<<" Enter data:";
    for(i=0;i<fs;i++)
    {
        cin>>f[i];
    }
return 0;
}




